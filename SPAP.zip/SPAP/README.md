# Student Performance Analysis & Analytics (SPAP)

**Author:** Armaan Deshmukh  
**Academic Level:** T.Y. B.Sc. Computer Science

---

## 📌 Project Overview
**SPAP (Student Performance Analysis & Analytics)** is a web-based educational analytics system designed for colleges and schools to monitor student progress, manage class-wise subjects, track attendance, and record examinations.

---

## ✨ Features & Modules

1. **Authentication System**: Secure user registration and login with password hashing.
2. **Interactive Analytics Dashboard**:
   - Total Enrolled Students, Overall Score Average, Pass Rate, and At-Risk alerts.
   - Subject-wise performance indicators with dynamic progress bars.
   - Top student leaderboard and real-time student search.
   - Class-level filtering.
3. **Subjects by Class & Default Presets**:
   - One-click generation of default subject presets for classes (e.g. *TY B.Sc CS*, *SY B.Sc CS*, *FY B.Sc CS*, *TY B.Com*, *SY B.Com*, *FY B.Com*, *General*).
   - Ability to add custom subjects for any course/class.
4. **Student Directory (CRUD)**:
   - Add, edit, search, and delete students with class and section filters.
5. **Marks Management**:
   - Single marks entry with real-time score validation.
   - Recent marks table with pass/fail badges and score history.
6. **Easy Attendance System**:
   - Quick **Mark All Present** and **Mark All Absent** 1-click batch actions.
   - Interactive status toggles (*Present / Absent / Late*).
   - Date picker and class filter.
7. **Excel & CSV Bulk Import/Export**:
   - Import students directly from `.xlsx`, `.xls`, or `.csv`.
   - Import marks in bulk from `.xlsx`, `.xls`, or `.csv`.
   - Download sample CSV templates for both students and marks.
   - Export student directory and marks dataset.
8. **Student Performance Reports**:
   - Individual student report cards with academic grades (O, A+, A, B+, B, C, F).
   - Attendance percentage breakdown.
   - Print-ready and PDF exportable format.

---

## 🚀 How to Run the Application

```powershell
# 1. Open project directory
cd SPAP

# 2. (Optional) Create and activate virtual environment
python -m venv venv
venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Start the application
python run.py
```

Then open your browser and navigate to: **`http://127.0.0.1:5000`**

---

## 💡 Tech Stack
- **Backend:** Python 3.11+, Flask, Flask-SQLAlchemy
- **Database:** SQLite (Local)
- **Data Analytics & Excel Processing:** Pandas, OpenPyXL
- **Security:** Werkzeug password hashing
- **Frontend:** HTML5, CSS3 (Modern Glass & Clean UI), Vanilla JavaScript
