import os
from datetime import date, timedelta
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import Config

db = SQLAlchemy()


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Ensure required runtime folders exist
    for folder in ('instance', 'uploads', 'exports', 'backups'):
        folder_path = os.path.join(app.root_path, '..', folder)
        os.makedirs(folder_path, exist_ok=True)

    db.init_app(app)

    # Import blueprints
    from app.routes.auth import auth_bp
    from app.routes.main import main_bp
    from app.routes.students import students_bp
    from app.routes.subjects import subjects_bp
    from app.routes.marks import marks_bp
    from app.routes.attendance import attendance_bp
    from app.routes.data import data_bp
    from app.routes.reports import reports_bp

    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(students_bp)
    app.register_blueprint(subjects_bp)
    app.register_blueprint(marks_bp)
    app.register_blueprint(attendance_bp)
    app.register_blueprint(data_bp)
    app.register_blueprint(reports_bp)

    # Create tables and initial demo data if database is empty
    with app.app_context():
        db.create_all()

        from app.models import User, Student, Subject, Mark, Attendance

        # Seed default admin user if none exists
        if User.query.count() == 0:
            default_admin = User(name='Armaan Deshmukh', email='armaan@example.com')
            default_admin.set_password('password123')
            db.session.add(default_admin)
            db.session.commit()

        # Seed initial subjects if none exist
        if Subject.query.count() == 0:
            initial_subjects = [
                Subject(name='Cloud Computing', class_name='TY B.Sc CS', code='CS601'),
                Subject(name='Data Science', class_name='TY B.Sc CS', code='CS602'),
                Subject(name='Software Engineering', class_name='TY B.Sc CS', code='CS603'),
                Subject(name='Information Security', class_name='TY B.Sc CS', code='CS604'),
                Subject(name='Web Services', class_name='TY B.Sc CS', code='CS605'),
            ]
            db.session.add_all(initial_subjects)
            db.session.commit()

        # Seed demo students, marks, and attendance if no students exist
        if Student.query.count() == 0:
            demo_students_data = [
                ('ST001', 'Armaan', 'Deshmukh', 'TY B.Sc CS', 'A', 'Male'),
                ('ST002', 'Rehan', 'Shaikh', 'TY B.Sc CS', 'A', 'Male'),
                ('ST003', 'Aman', 'Patil', 'TY B.Sc CS', 'A', 'Male'),
                ('ST004', 'Suhana', 'Deshmukh', 'TY B.Sc CS', 'A', 'Female'),
                ('ST005', 'Aisha', 'Khan', 'TY B.Sc CS', 'A', 'Female'),
                ('ST006', 'Arshad', 'Patel', 'TY B.Sc CS', 'A', 'Male'),
                ('ST007', 'Abuzar', 'Shaikh', 'TY B.Sc CS', 'A', 'Male'),
                ('ST008', 'Amanat', 'Pathan', 'TY B.Sc CS', 'A', 'Female'),
            ]

            created_students = []
            for code, first, last, cls, sec, gender in demo_students_data:
                student = Student(
                    student_code=code,
                    first_name=first,
                    last_name=last,
                    class_name=cls,
                    section=sec,
                    gender=gender,
                    guardian_name='Guardian',
                    guardian_contact='9876543210'
                )
                db.session.add(student)
                created_students.append(student)

            db.session.commit()

            # Seed demo marks
            subjects = Subject.query.filter_by(class_name='TY B.Sc CS').all()
            score_matrix = [
                [85, 78, 92, 88, 81],
                [72, 68, 75, 70, 74],
                [94, 91, 96, 89, 95],
                [58, 62, 55, 60, 59],
                [82, 85, 80, 78, 86],
                [32, 28, 41, 35, 30],
                [65, 70, 62, 68, 66],
                [48, 52, 45, 50, 49],
            ]

            for student, scores in zip(created_students, score_matrix):
                for subject, score in zip(subjects, scores):
                    mark = Mark(
                        student_id=student.id,
                        subject_id=subject.id,
                        exam='Internal',
                        term='Semester 1',
                        marks_obtained=score,
                        max_marks=100.0
                    )
                    db.session.add(mark)

            # Seed demo attendance (past 10 days)
            present_days_list = [10, 8, 10, 9, 8, 6, 8, 7]
            today = date.today()

            for i, student in enumerate(created_students):
                p_count = present_days_list[i]
                for day_offset in range(10):
                    record_date = today - timedelta(days=day_offset)
                    status = 'P' if day_offset < p_count else 'A'
                    attendance = Attendance(
                        student_id=student.id,
                        date=record_date,
                        status=status
                    )
                    db.session.add(attendance)

            db.session.commit()

    return app
