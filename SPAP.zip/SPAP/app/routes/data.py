import io
import os
import pandas as pd
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, send_file, current_app
from app import db
from app.models import Student, Subject, Mark

data_bp = Blueprint('data', __name__, url_prefix='/data')


def is_authenticated():
    return 'user_id' in session


@data_bp.route('/', methods=['GET', 'POST'])
def index():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        import_type = request.form.get('import_type', 'students')
        file = request.files.get('file')

        if not file or not file.filename:
            flash('Please select an Excel or CSV file to upload.', 'error')
            return render_template('data.html')

        filename = file.filename.lower()
        if not (filename.endswith('.xlsx') or filename.endswith('.xls') or filename.endswith('.csv')):
            flash('Invalid file format. Please upload an Excel (.xlsx, .xls) or CSV (.csv) file.', 'error')
            return render_template('data.html')

        try:
            # Read DataFrame from file
            if filename.endswith('.csv'):
                df = pd.read_csv(file)
            else:
                df = pd.read_excel(file)

            # Clean column headers
            df.columns = [str(col).strip() for col in df.columns]

            # -------------------------------------------------------------
            # IMPORT STUDENTS
            # -------------------------------------------------------------
            if import_type == 'students':
                added_count = 0
                updated_count = 0

                for _, row in df.iterrows():
                    # Handle various common column names
                    code = str(
                        row.get('student_code') or
                        row.get('Student ID') or
                        row.get('Roll No') or
                        row.get('student_id') or
                        ''
                    ).strip()

                    first_name = str(
                        row.get('first_name') or
                        row.get('First Name') or
                        row.get('name') or
                        row.get('Name') or
                        ''
                    ).strip()

                    last_name = str(
                        row.get('last_name') or
                        row.get('Last Name') or
                        ''
                    ).strip()

                    class_name = str(
                        row.get('class_name') or
                        row.get('Class') or
                        'TY B.Sc CS'
                    ).strip()

                    section = str(
                        row.get('section') or
                        row.get('Section') or
                        'A'
                    ).strip().upper()

                    gender = str(
                        row.get('gender') or
                        row.get('Gender') or
                        'Male'
                    ).strip()

                    guardian_name = str(
                        row.get('guardian_name') or
                        row.get('Guardian Name') or
                        ''
                    ).strip()

                    guardian_contact = str(
                        row.get('guardian_contact') or
                        row.get('Guardian Contact') or
                        row.get('Contact') or
                        ''
                    ).strip()

                    if not code or not first_name:
                        continue  # Skip invalid rows

                    student = Student.query.filter_by(student_code=code).first()
                    if student:
                        # Update existing student
                        student.first_name = first_name
                        student.last_name = last_name
                        student.class_name = class_name
                        student.section = section
                        student.gender = gender
                        if guardian_name:
                            student.guardian_name = guardian_name
                        if guardian_contact:
                            student.guardian_contact = guardian_contact
                        updated_count += 1
                    else:
                        # Add new student
                        new_student = Student(
                            student_code=code,
                            first_name=first_name,
                            last_name=last_name,
                            class_name=class_name,
                            section=section,
                            gender=gender,
                            guardian_name=guardian_name or None,
                            guardian_contact=guardian_contact or None
                        )
                        db.session.add(new_student)
                        added_count += 1

                db.session.commit()
                flash(f"Students import complete: {added_count} new students added, {updated_count} existing updated.", 'success')

            # -------------------------------------------------------------
            # IMPORT MARKS
            # -------------------------------------------------------------
            elif import_type == 'marks':
                marks_added = 0
                skipped = 0

                for _, row in df.iterrows():
                    code = str(
                        row.get('student_code') or
                        row.get('Student ID') or
                        row.get('student_id') or
                        ''
                    ).strip()

                    subject_name = str(
                        row.get('subject_name') or
                        row.get('Subject') or
                        row.get('subject') or
                        ''
                    ).strip()

                    exam = str(row.get('exam') or row.get('Exam') or 'Internal').strip()
                    term = str(row.get('term') or row.get('Term') or 'Semester 1').strip()

                    try:
                        obtained_raw = row.get('marks_obtained') if 'marks_obtained' in row else row.get('Marks', row.get('marks', 0))
                        marks_obtained = float(obtained_raw)

                        max_raw = row.get('max_marks') if 'max_marks' in row else row.get('Max Marks', row.get('max_marks', 100))
                        max_marks = float(max_raw) if pd.notnull(max_raw) else 100.0
                    except (ValueError, TypeError):
                        skipped += 1
                        continue

                    if not code or not subject_name:
                        skipped += 1
                        continue

                    student = Student.query.filter_by(student_code=code).first()
                    if not student:
                        skipped += 1
                        continue

                    # Find subject or auto-create for student's class
                    subject = Subject.query.filter_by(name=subject_name, class_name=student.class_name).first()
                    if not subject:
                        subject = Subject.query.filter_by(name=subject_name).first()
                    if not subject:
                        subject = Subject(name=subject_name, class_name=student.class_name)
                        db.session.add(subject)
                        db.session.flush()

                    new_mark = Mark(
                        student_id=student.id,
                        subject_id=subject.id,
                        exam=exam,
                        term=term,
                        marks_obtained=marks_obtained,
                        max_marks=max_marks
                    )
                    db.session.add(new_mark)
                    marks_added += 1

                db.session.commit()
                if marks_added > 0:
                    flash(f"Marks import complete: Successfully imported {marks_added} marks entries! ({skipped} rows skipped)", 'success')
                else:
                    flash(f"No valid marks were imported. Please check that student IDs and subjects match existing records.", 'error')

        except Exception as err:
            db.session.rollback()
            flash(f"Error importing file: {str(err)}", 'error')

    return render_template('data.html')


@data_bp.route('/template/<template_type>')
def download_template(template_type):
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    if template_type == 'students':
        sample_data = [
            {
                'student_code': 'ST101',
                'first_name': 'Rahul',
                'last_name': 'Sharma',
                'class_name': 'TY B.Sc CS',
                'section': 'A',
                'gender': 'Male',
                'guardian_name': 'Suresh Sharma',
                'guardian_contact': '9876543210'
            },
            {
                'student_code': 'ST102',
                'first_name': 'Pooja',
                'last_name': 'Verma',
                'class_name': 'TY B.Sc CS',
                'section': 'A',
                'gender': 'Female',
                'guardian_name': 'Ramesh Verma',
                'guardian_contact': '9876543211'
            }
        ]
        filename = 'students_template.csv'
        df = pd.DataFrame(sample_data)
    else:  # marks template
        sample_data = [
            {
                'student_code': 'ST001',
                'subject_name': 'Cloud Computing',
                'exam': 'Internal',
                'term': 'Semester 1',
                'marks_obtained': 85.0,
                'max_marks': 100.0
            },
            {
                'student_code': 'ST001',
                'subject_name': 'Data Science',
                'exam': 'Internal',
                'term': 'Semester 1',
                'marks_obtained': 78.0,
                'max_marks': 100.0
            }
        ]
        filename = 'marks_template.csv'
        df = pd.DataFrame(sample_data)

    output = io.BytesIO()
    df.to_csv(output, index=False)
    output.seek(0)

    return send_file(
        output,
        mimetype='text/csv',
        as_attachment=True,
        download_name=filename
    )


@data_bp.route('/export/students')
def export_students():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    students = Student.query.order_by(Student.student_code).all()
    data = [
        {
            'Student ID': s.student_code,
            'First Name': s.first_name,
            'Last Name': s.last_name,
            'Class': s.class_name,
            'Section': s.section,
            'Gender': s.gender,
            'Guardian Name': s.guardian_name or '',
            'Guardian Contact': s.guardian_contact or ''
        }
        for s in students
    ]
    df = pd.DataFrame(data)
    output = io.BytesIO()
    df.to_csv(output, index=False)
    output.seek(0)

    return send_file(
        output,
        mimetype='text/csv',
        as_attachment=True,
        download_name='students_export.csv'
    )


@data_bp.route('/export/marks')
def export_marks():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    marks = Mark.query.order_by(Mark.id.desc()).all()
    data = [
        {
            'Student ID': m.student.student_code,
            'Student Name': m.student.name,
            'Class': m.student.class_name,
            'Subject': m.subject.name,
            'Exam': m.exam,
            'Term': m.term,
            'Marks Obtained': m.marks_obtained,
            'Max Marks': m.max_marks,
            'Percentage': f"{m.percentage}%"
        }
        for m in marks
    ]
    df = pd.DataFrame(data)
    output = io.BytesIO()
    df.to_csv(output, index=False)
    output.seek(0)

    return send_file(
        output,
        mimetype='text/csv',
        as_attachment=True,
        download_name='marks_export.csv'
    )
