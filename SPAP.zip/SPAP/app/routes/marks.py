from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app import db
from app.models import Student, Subject, Mark

marks_bp = Blueprint('marks', __name__, url_prefix='/marks')


def is_authenticated():
    return 'user_id' in session


@marks_bp.route('/', methods=['GET', 'POST'])
def index():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        student_id = request.form.get('student_id')
        subject_id = request.form.get('subject_id')
        exam = request.form.get('exam', 'Internal').strip()
        term = request.form.get('term', 'Semester 1').strip()

        try:
            marks_obtained = float(request.form.get('marks', 0))
            max_marks = float(request.form.get('max_marks', 100))

            if marks_obtained < 0:
                flash('Marks obtained cannot be negative.', 'error')
            elif max_marks <= 0:
                flash('Maximum marks must be greater than 0.', 'error')
            elif marks_obtained > max_marks:
                flash(f'Marks obtained ({marks_obtained}) cannot exceed maximum marks ({max_marks}).', 'error')
            else:
                student = Student.query.get(student_id)
                subject = Subject.query.get(subject_id)

                if not student or not subject:
                    flash('Invalid student or subject selected.', 'error')
                else:
                    mark = Mark(
                        student_id=student.id,
                        subject_id=subject.id,
                        exam=exam,
                        term=term,
                        marks_obtained=marks_obtained,
                        max_marks=max_marks
                    )
                    db.session.add(mark)
                    db.session.commit()
                    flash(f"Marks saved for {student.name} in {subject.name} ({marks_obtained}/{max_marks})!", 'success')
                    return redirect(url_for('marks.index'))
        except ValueError:
            flash('Please enter valid numeric values for marks.', 'error')

    students = Student.query.order_by(Student.class_name, Student.student_code).all()
    subjects = Subject.query.order_by(Subject.class_name, Subject.name).all()
    recent_marks = Mark.query.order_by(Mark.id.desc()).limit(100).all()

    return render_template(
        'marks.html',
        students=students,
        subjects=subjects,
        marks=recent_marks
    )


@marks_bp.route('/<int:id>/delete', methods=['POST'])
def delete(id):
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    mark = Mark.query.get_or_404(id)
    db.session.delete(mark)
    db.session.commit()
    flash('Mark entry deleted successfully.', 'success')
    return redirect(url_for('marks.index'))
