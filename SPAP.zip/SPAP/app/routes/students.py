from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app import db
from app.models import Student, Subject

students_bp = Blueprint('students', __name__, url_prefix='/students')


def is_authenticated():
    return 'user_id' in session


@students_bp.route('/')
def list_students():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    search_query = request.args.get('q', '').strip()
    selected_class = request.args.get('class_name', '').strip()

    query = Student.query
    if search_query:
        query = query.filter(
            (Student.first_name.ilike(f"%{search_query}%")) |
            (Student.last_name.ilike(f"%{search_query}%")) |
            (Student.student_code.ilike(f"%{search_query}%"))
        )
    if selected_class:
        query = query.filter_by(class_name=selected_class)

    students = query.order_by(Student.student_code).all()

    # Get list of classes for filter dropdown
    classes = [c[0] for c in db.session.query(Student.class_name).distinct().all() if c[0]]

    return render_template(
        'students.html',
        students=students,
        classes=sorted(classes),
        q=search_query,
        selected_class=selected_class
    )


@students_bp.route('/add', methods=['GET', 'POST'])
def add():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        student_code = request.form.get('student_code', '').strip().upper()
        first_name = request.form.get('first_name', '').strip()
        last_name = request.form.get('last_name', '').strip()
        class_name = request.form.get('class_name', 'TY B.Sc CS').strip()
        section = request.form.get('section', 'A').strip().upper()
        gender = request.form.get('gender', 'Male')
        guardian_name = request.form.get('guardian_name', '').strip()
        guardian_contact = request.form.get('guardian_contact', '').strip()

        if not student_code or not first_name or not last_name:
            flash('Student ID, First Name, and Last Name are required.', 'error')
            return render_template('student_form.html', student=None)

        if Student.query.filter_by(student_code=student_code).first():
            flash(f"A student with ID '{student_code}' already exists.", 'error')
            return render_template('student_form.html', student=None)

        student = Student(
            student_code=student_code,
            first_name=first_name,
            last_name=last_name,
            class_name=class_name,
            section=section,
            gender=gender,
            guardian_name=guardian_name or None,
            guardian_contact=guardian_contact or None
        )
        db.session.add(student)
        db.session.commit()

        flash(f"Student '{student.name}' added successfully!", 'success')
        return redirect(url_for('students.list_students'))

    return render_template('student_form.html', student=None)


@students_bp.route('/<int:id>/edit', methods=['GET', 'POST'])
def edit(id):
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    student = Student.query.get_or_404(id)

    if request.method == 'POST':
        new_code = request.form.get('student_code', '').strip().upper()

        if new_code != student.student_code and Student.query.filter_by(student_code=new_code).first():
            flash(f"Student ID '{new_code}' is already taken.", 'error')
            return render_template('student_form.html', student=student)

        student.student_code = new_code
        student.first_name = request.form.get('first_name', '').strip()
        student.last_name = request.form.get('last_name', '').strip()
        student.class_name = request.form.get('class_name', 'TY B.Sc CS').strip()
        student.section = request.form.get('section', 'A').strip().upper()
        student.gender = request.form.get('gender', 'Male')
        student.guardian_name = request.form.get('guardian_name', '').strip()
        student.guardian_contact = request.form.get('guardian_contact', '').strip()

        db.session.commit()
        flash(f"Student '{student.name}' updated successfully!", 'success')
        return redirect(url_for('students.list_students'))

    return render_template('student_form.html', student=student)


@students_bp.route('/<int:id>/delete', methods=['POST'])
def delete(id):
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    student = Student.query.get_or_404(id)
    student_name = student.name
    db.session.delete(student)
    db.session.commit()

    flash(f"Student '{student_name}' deleted.", 'success')
    return redirect(url_for('students.list_students'))
