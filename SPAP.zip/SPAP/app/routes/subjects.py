from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app import db
from app.models import Subject

subjects_bp = Blueprint('subjects', __name__, url_prefix='/subjects')

# Predefined default subjects by class
DEFAULT_SUBJECTS_MAP = {
    'TY B.Sc CS': [
        ('Cloud Computing', 'CS601'),
        ('Data Science', 'CS602'),
        ('Software Engineering', 'CS603'),
        ('Information Security', 'CS604'),
        ('Web Services', 'CS605')
    ],
    'SY B.Sc CS': [
        ('Core Java', 'CS401'),
        ('Python Programming', 'CS402'),
        ('Database Management Systems', 'CS403'),
        ('Computer Networks', 'CS404'),
        ('Operating Systems', 'CS405')
    ],
    'FY B.Sc CS': [
        ('C Programming', 'CS201'),
        ('Python Basics', 'CS202'),
        ('Discrete Mathematics', 'CS203'),
        ('Digital Electronics', 'CS204'),
        ('Linux Fundamentals', 'CS205')
    ],
    'TY B.Com': [
        ('Financial Accounting', 'COM601'),
        ('Cost Accounting', 'COM602'),
        ('Direct & Indirect Taxes', 'COM603'),
        ('Business Economics', 'COM604'),
        ('Auditing', 'COM605')
    ],
    'SY B.Com': [
        ('Accountancy & Financial Management', 'COM401'),
        ('Business Law', 'COM402'),
        ('Commerce III', 'COM403'),
        ('Business Economics III', 'COM404'),
        ('Company Secretarial Practice', 'COM405')
    ],
    'FY B.Com': [
        ('Accountancy I', 'COM201'),
        ('Commerce I', 'COM202'),
        ('Business Communication', 'COM203'),
        ('Environmental Studies', 'COM204'),
        ('Business Mathematics', 'COM205')
    ],
    'General': [
        ('Mathematics', 'GEN101'),
        ('Science', 'GEN102'),
        ('English', 'GEN103'),
        ('Computer Science', 'GEN104'),
        ('Social Science', 'GEN105')
    ]
}


def is_authenticated():
    return 'user_id' in session


@subjects_bp.route('/', methods=['GET', 'POST'])
def index():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    selected_class = request.args.get('class_name', '').strip()

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'add_single':
            name = request.form.get('name', '').strip()
            class_name = request.form.get('class_name', 'TY B.Sc CS').strip()
            code = request.form.get('code', '').strip()

            if not name:
                flash('Subject name is required.', 'error')
            else:
                existing = Subject.query.filter_by(name=name, class_name=class_name).first()
                if existing:
                    flash(f"Subject '{name}' already exists for {class_name}.", 'error')
                else:
                    new_subject = Subject(name=name, class_name=class_name, code=code or None)
                    db.session.add(new_subject)
                    db.session.commit()
                    flash(f"Subject '{name}' added successfully for {class_name}!", 'success')
                    return redirect(url_for('subjects.index', class_name=class_name))

        elif action == 'create_defaults':
            target_class = request.form.get('target_class', '').strip()
            if not target_class:
                flash('Please select a class to load default subjects.', 'error')
            else:
                defaults = DEFAULT_SUBJECTS_MAP.get(target_class, DEFAULT_SUBJECTS_MAP['General'])
                added_count = 0

                for sub_name, sub_code in defaults:
                    existing = Subject.query.filter_by(name=sub_name, class_name=target_class).first()
                    if not existing:
                        db.session.add(Subject(name=sub_name, class_name=target_class, code=sub_code))
                        added_count += 1

                db.session.commit()
                if added_count > 0:
                    flash(f"Created {added_count} default subjects for '{target_class}'.", 'success')
                else:
                    flash(f"All default subjects for '{target_class}' already exist.", 'info')

                return redirect(url_for('subjects.index', class_name=target_class))

    # Fetch subjects
    query = Subject.query
    if selected_class:
        query = query.filter_by(class_name=selected_class)

    subjects = query.order_by(Subject.class_name, Subject.name).all()

    # Get distinct classes currently in database + presets
    db_classes = [c[0] for c in db.session.query(Subject.class_name).distinct().all() if c[0]]
    all_classes = sorted(list(set(db_classes + list(DEFAULT_SUBJECTS_MAP.keys()))))

    return render_template(
        'subjects.html',
        subjects=subjects,
        all_classes=all_classes,
        selected_class=selected_class,
        default_classes=list(DEFAULT_SUBJECTS_MAP.keys())
    )


@subjects_bp.route('/<int:id>/delete', methods=['POST'])
def delete(id):
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    subject = Subject.query.get_or_404(id)
    class_name = subject.class_name
    db.session.delete(subject)
    db.session.commit()
    flash(f"Subject '{subject.name}' was deleted.", 'success')
    return redirect(url_for('subjects.index', class_name=class_name))
