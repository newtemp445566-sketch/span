from flask import Blueprint, render_template, session, redirect, url_for, request
from app import db
from app.models import Student, Mark, Attendance

reports_bp = Blueprint('reports', __name__, url_prefix='/reports')


def is_authenticated():
    return 'user_id' in session


def calculate_grade(percentage):
    if percentage >= 85:
        return 'O (Outstanding)'
    elif percentage >= 75:
        return 'A+ (Excellent)'
    elif percentage >= 65:
        return 'A (Very Good)'
    elif percentage >= 55:
        return 'B+ (Good)'
    elif percentage >= 45:
        return 'B (Above Average)'
    elif percentage >= 35:
        return 'C (Pass)'
    else:
        return 'F (Fail)'


@reports_bp.route('/')
def index():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    search_query = request.args.get('q', '').strip()
    selected_class = request.args.get('class_name', '').strip()

    query = Student.query
    if search_query:
        query = query.filter(
            (Student.first_name.ilike(f"%{search_query}%")) |
            (Student.last_name.ilike(f"%{search_query}%")) |
            (Student.student_code.ilike(f"%{search_query}%"))
        )
    if selected_class:
        query = query.filter_by(class_name=selected_class)

    students = query.order_by(Student.student_code).all()
    classes = [c[0] for c in db.session.query(Student.class_name).distinct().all() if c[0]]

    return render_template(
        'reports.html',
        students=students,
        classes=sorted(classes),
        q=search_query,
        selected_class=selected_class
    )


@reports_bp.route('/student/<int:id>')
def student_report(id):
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    student = Student.query.get_or_404(id)
    marks = Mark.query.filter_by(student_id=student.id).order_by(Mark.id.asc()).all()

    # Calculate academic stats
    total_obtained = sum(m.marks_obtained for m in marks)
    total_max = sum(m.max_marks for m in marks)
    overall_percentage = round((total_obtained / total_max * 100), 2) if total_max > 0 else 0.0
    grade = calculate_grade(overall_percentage)

    # Calculate attendance stats
    attendance_records = Attendance.query.filter_by(student_id=student.id).all()
    total_days = len(attendance_records)
    present_days = sum(1 for a in attendance_records if a.status == 'P')
    attendance_rate = round((present_days / total_days * 100), 1) if total_days > 0 else 100.0

    return render_template(
        'student_report.html',
        student=student,
        marks=marks,
        total_obtained=total_obtained,
        total_max=total_max,
        overall_percentage=overall_percentage,
        grade=grade,
        total_days=total_days,
        present_days=present_days,
        attendance_rate=attendance_rate
    )
