from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app import db
from app.models import Student, Attendance

attendance_bp = Blueprint('attendance', __name__, url_prefix='/attendance')


def is_authenticated():
    return 'user_id' in session


@attendance_bp.route('/', methods=['GET', 'POST'])
def index():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    selected_date_str = request.args.get('date', date.today().isoformat())
    selected_class = request.args.get('class_name', '').strip()

    try:
        attendance_date = date.fromisoformat(selected_date_str)
    except ValueError:
        attendance_date = date.today()
        selected_date_str = attendance_date.isoformat()

    if request.method == 'POST':
        post_date_str = request.form.get('date', selected_date_str)
        try:
            attendance_date = date.fromisoformat(post_date_str)
        except ValueError:
            attendance_date = date.today()

        # Query relevant students
        student_query = Student.query
        class_filter = request.form.get('class_filter', '').strip()
        if class_filter:
            student_query = student_query.filter_by(class_name=class_filter)

        students_to_update = student_query.all()
        saved_count = 0

        for student in students_to_update:
            status = request.form.get(f"status_{student.id}", 'P')
            record = Attendance.query.filter_by(student_id=student.id, date=attendance_date).first()

            if record:
                record.status = status
            else:
                new_record = Attendance(student_id=student.id, date=attendance_date, status=status)
                db.session.add(new_record)
            saved_count += 1

        db.session.commit()
        flash(f"Attendance recorded for {saved_count} students on {attendance_date.strftime('%d %b %Y')}!", 'success')
        return redirect(url_for('attendance.index', date=attendance_date.isoformat(), class_name=class_filter))

    # GET Request: Prepare students and their current status for selected date
    student_query = Student.query
    if selected_class:
        student_query = student_query.filter_by(class_name=selected_class)

    students = student_query.order_by(Student.student_code).all()

    # Fetch existing records for this date
    existing_records = {
        rec.student_id: rec.status
        for rec in Attendance.query.filter_by(date=attendance_date).all()
    }

    # Available classes for filtering
    classes = [c[0] for c in db.session.query(Student.class_name).distinct().all() if c[0]]

    return render_template(
        'attendance.html',
        students=students,
        classes=sorted(classes),
        selected_class=selected_class,
        selected_date=selected_date_str,
        existing_records=existing_records
    )
