from flask import Blueprint, render_template, redirect, url_for, session, request
from app import db
from app.models import Student, Subject, Mark, Attendance

main_bp = Blueprint('main', __name__)


def is_authenticated():
    return 'user_id' in session


@main_bp.route('/')
def home():
    if is_authenticated():
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('auth.login'))


@main_bp.route('/dashboard')
def dashboard():
    if not is_authenticated():
        return redirect(url_for('auth.login'))

    selected_class = request.args.get('class_name', '').strip()

    # Base student query
    student_query = Student.query
    if selected_class:
        student_query = student_query.filter_by(class_name=selected_class)

    students_list = student_query.all()
    total_students = len(students_list)
    student_ids = [s.id for s in students_list]

    # Marks analytics
    if student_ids:
        marks = Mark.query.filter(Mark.student_id.in_(student_ids)).all()
    else:
        marks = []

    if marks:
        avg_score = round(sum(m.percentage for m in marks) / len(marks), 1)
        pass_count = sum(1 for m in marks if m.percentage >= 35.0)
        pass_rate = round((pass_count / len(marks)) * 100, 1)
    else:
        avg_score = 0.0
        pass_rate = 0.0

    # At-risk students (average < 35%)
    at_risk_count = 0
    student_leaderboard = []

    for student in students_list:
        student_marks = student.marks
        if student_marks:
            student_avg = round(sum(m.percentage for m in student_marks) / len(student_marks), 1)
            if student_avg < 35.0:
                at_risk_count += 1
            student_leaderboard.append({
                'id': student.id,
                'name': student.name,
                'student_code': student.student_code,
                'class_name': student.class_name,
                'avg': student_avg
            })
        else:
            student_leaderboard.append({
                'id': student.id,
                'name': student.name,
                'student_code': student.student_code,
                'class_name': student.class_name,
                'avg': 0.0
            })

    # Sort top students
    student_leaderboard.sort(key=lambda x: x['avg'], reverse=True)
    top_students = student_leaderboard[:5]

    # Attendance rate
    if student_ids:
        attendance_records = Attendance.query.filter(Attendance.student_id.in_(student_ids)).all()
    else:
        attendance_records = []

    if attendance_records:
        present_count = sum(1 for a in attendance_records if a.status == 'P')
        attendance_rate = round((present_count / len(attendance_records)) * 100, 1)
    else:
        attendance_rate = 0.0

    # Subject-wise analytics
    subject_query = Subject.query
    if selected_class:
        subject_query = subject_query.filter_by(class_name=selected_class)
    subjects = subject_query.all()

    subject_data = []
    for sub in subjects:
        sub_marks = [m.percentage for m in sub.marks if m.student_id in student_ids] if student_ids else []
        sub_avg = round(sum(sub_marks) / len(sub_marks), 1) if sub_marks else 0.0
        subject_data.append({
            'name': sub.name,
            'class_name': sub.class_name,
            'avg': sub_avg,
            'count': len(sub_marks)
        })

    # Classes for filter dropdown
    all_classes = [c[0] for c in db.session.query(Student.class_name).distinct().all() if c[0]]

    return render_template(
        'dashboard.html',
        total_students=total_students,
        avg_score=avg_score,
        pass_rate=pass_rate,
        at_risk_count=at_risk_count,
        attendance_rate=attendance_rate,
        subject_data=subject_data,
        top_students=top_students,
        all_students=student_leaderboard,
        all_classes=sorted(all_classes),
        selected_class=selected_class
    )
